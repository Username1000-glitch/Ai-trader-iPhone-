const START=100, MAX_RISK=1, DAILY_LIMIT=3, MAX_POS=2;
const BASE={AAPL:220,MSFT:500,NVDA:180,"BTC-USD":95000,"ETH-USD":3200,"SOL-USD":180,"EUR-USD":1.08,"GBP-USD":1.29,"USD-JPY":150,"AAPL-CALL-SIM":4.5,"SPY-PUT-SIM":5.2};
const GROUPS={Stocks:["AAPL","MSFT","NVDA"],Crypto:["BTC-USD","ETH-USD","SOL-USD"],Forex:["EUR-USD","GBP-USD","USD-JPY"],Options:["AAPL-CALL-SIM","SPY-PUT-SIM"]};
let state=load(), timer=null;
function fresh(){let prices={...BASE},hist={};Object.keys(BASE).forEach(s=>hist[s]=Array.from({length:35},()=>BASE[s]*(1+(Math.random()-.5)*.04)).concat(BASE[s]));return {cash:START,prices,hist,positions:{},trades:[],equityHistory:[],signals:{},lastRun:null};}
function load(){try{let s=JSON.parse(localStorage.getItem("aitrader-v1"));return s&&s.prices?s:fresh()}catch{return fresh()}}
function save(){localStorage.setItem("aitrader-v1",JSON.stringify(state))}
function money(n){return "$"+Number(n).toFixed(2)}
function rsi(a){let d=[];for(let i=1;i<a.length;i++)d.push(a[i]-a[i-1]);let g=d.slice(-14).map(x=>Math.max(0,x)),l=d.slice(-14).map(x=>Math.max(0,-x));let ag=g.reduce((x,y)=>x+y,0)/14,al=l.reduce((x,y)=>x+y,0)/14;return al===0?100:100-100/(1+ag/al)}
function ema(a,n){let k=2/(n+1),v=a[0];for(let x of a.slice(1))v=x*k+v*(1-k);return v}
function signal(s){let a=state.hist[s],r=rsi(a);return {r,signal:r<35&&ema(a.slice(-25),9)>ema(a.slice(-25),21)?"BUY CANDIDATE":r>75?"EXIT WATCH":"HOLD"}}
function dailyPnl(){let d=new Date().toDateString();return state.trades.filter(t=>new Date(t.time).toDateString()===d).reduce((x,t)=>x+t.pnl,0)}
function equity(){return state.cash+Object.values(state.positions).reduce((v,p)=>v+p.qty*state.prices[p.symbol],0)}
function close(s,reason){let p=state.positions[s],price=state.prices[s],pnl=(price-p.entry)*p.qty;state.cash+=price*p.qty;state.trades.unshift({symbol:s,market:p.market,entry:p.entry,exit:price,qty:p.qty,pnl,time:new Date().toISOString(),reason});delete state.positions[s]}
function cycle(){
 Object.keys(state.prices).forEach(s=>{let vol=s.includes("BTC")||s.includes("ETH")||s.includes("SOL")?.012:s.includes("SIM")?.018:.004;state.prices[s]=Math.max(.00001,state.prices[s]*(1+(Math.random()-.4999)*vol));state.hist[s].push(state.prices[s]);state.hist[s]=state.hist[s].slice(-120)});
 Object.keys(state.positions).forEach(s=>{let sig=signal(s).signal;if(state.prices[s]<=state.positions[s].stop||sig==="EXIT WATCH")close(s,"Stop / exit signal")});
 let candidates=[];state.signals={};Object.entries(GROUPS).forEach(([m,ss])=>ss.forEach(s=>{let z=signal(s);state.signals[s]={market:m,...z};if(z.signal==="BUY CANDIDATE")candidates.push({s,m})}));
 candidates.forEach(({s,m})=>{if(Object.keys(state.positions).length>=MAX_POS||state.positions[s]||dailyPnl()<=-DAILY_LIMIT)return;let price=state.prices[s],stop=price*.97,qty=Math.min(MAX_RISK/(price-stop),state.cash/price);if(qty>0&&qty*price<=state.cash){state.cash-=qty*price;state.positions[s]={symbol:s,market:m,qty,entry:price,stop,time:new Date().toISOString()}}});
 state.lastRun=new Date().toISOString();state.equityHistory.push({time:state.lastRun,equity:equity()});state.equityHistory=state.equityHistory.slice(-100);save();render();
}
function render(){
 let eq=equity(),pnl=eq-START;document.getElementById("equity").textContent=money(eq);document.getElementById("cash").textContent=money(state.cash);document.getElementById("totalPnl").textContent=(pnl>=0?"+":"")+money(pnl)+" total return";document.getElementById("totalPnl").className="pnl "+(pnl>=0?"gain":"loss");document.getElementById("openCount").textContent=Object.keys(state.positions).length;document.getElementById("dailyPnl").textContent=(dailyPnl()>=0?"+":"")+money(dailyPnl());
 document.getElementById("lastUpdated").textContent=state.lastRun?new Date(state.lastRun).toLocaleTimeString():"Not started";
 let rows="";Object.entries(GROUPS).forEach(([m,ss])=>ss.forEach(s=>{let z=state.signals[s]||signal(s);let cls=z.signal==="BUY CANDIDATE"?"buy":z.signal==="EXIT WATCH"?"exit":"";rows+=`<tr><td>${m}</td><td>${s}</td><td class="right">${state.prices[s].toFixed(s.includes("USD")&&!s.includes("BTC")&&!s.includes("ETH")?4:2)}</td><td class="right">${z.r.toFixed(1)}</td><td class="signal ${cls}">${z.signal}</td></tr>`}));document.getElementById("quotes").innerHTML=rows;
 let ps=Object.values(state.positions);document.getElementById("positions").innerHTML=ps.length?ps.map(p=>{let v=(state.prices[p.symbol]-p.entry)*p.qty;return `<div class="position"><div><b>${p.symbol}</b><small>${p.market} · Qty ${p.qty.toFixed(6)} · Stop ${p.stop.toFixed(4)}</small></div><b class="${v>=0?"gain":"loss"}">${v>=0?"+":""}${money(v)}</b></div>`}).join(""):'<div class="empty">No open positions yet.</div>';
 document.getElementById("history").innerHTML=state.trades.length?state.trades.slice(0,20).map(t=>`<div class="trade"><div><b>${t.symbol}</b><small>${t.reason} · ${new Date(t.time).toLocaleString()}</small></div><b class="${t.pnl>=0?"gain":"loss"}">${t.pnl>=0?"+":""}${money(t.pnl)}</b></div>`).join(""):'<div class="empty">No closed trades yet.</div>';
}
document.getElementById("cycleBtn").onclick=()=>cycle();
document.getElementById("autoBtn").onclick=()=>{if(timer){clearInterval(timer);timer=null;document.getElementById("autoBtn").textContent="Start auto-simulation";document.getElementById("runState").textContent="PAUSED"}else{cycle();timer=setInterval(cycle,15000);document.getElementById("autoBtn").textContent="Pause auto-simulation";document.getElementById("runState").textContent="RUNNING"}}; 
document.getElementById("resetBtn").onclick=()=>{if(confirm("Reset the simulated $100 account and erase its local history?")){if(timer){clearInterval(timer);timer=null}state=fresh();save();render();document.getElementById("autoBtn").textContent="Start auto-simulation";document.getElementById("runState").textContent="READY"}};
document.addEventListener("visibilitychange",()=>{if(document.hidden&&timer){clearInterval(timer);timer=null;document.getElementById("autoBtn").textContent="Start auto-simulation";document.getElementById("runState").textContent="PAUSED — APP BACKGROUND"}})
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
render();
