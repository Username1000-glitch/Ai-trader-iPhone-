# AI Trader iPhone PWA — Version 1

A home-screen-installable web app for a **paper-only** trading simulation.

## What it does
- Shows simulated stock, crypto, forex, and illustrative options markets.
- Runs a small RSI/EMA signal demo.
- Simulates entries/exits with a $100 starting balance, $1 max planned risk per trade, $3 daily realized-loss guard, and at most two open positions.
- Saves paper account state in the browser's local storage.
- Can be added to an iPhone Home Screen after deployment to HTTPS hosting.

## Important limits
- No broker integration, no real orders, and no real market data.
- Prices are synthetic random-walk data. The options tickers are placeholders, not real contracts.
- Auto-simulation runs only while the page is open and active. iOS can pause web apps in the background; this is **not** a 24/7 unattended trading bot.
- Data is stored on that browser/device. Clearing Safari website data or using a different browser/device may erase or separate it.
- The $1 risk figure is a simplified estimate, not a guaranteed maximum loss.

## Free deployment using GitHub Pages
You need an iPhone and a GitHub account. GitHub Pages can host this static app over HTTPS for free on eligible public repositories.

1. On iPhone Safari, go to https://github.com and create/sign into an account.
2. Create a new **public** repository named `ai-trader-iphone`.
3. Upload all files from this folder to the repository root: `index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, and `icon-512.png`.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. Your address will look like `https://YOUR-USERNAME.github.io/ai-trader-iphone/`.

Do not put passwords, API keys, brokerage credentials, or personal financial information in this public repository. This app does not need any secrets.

## Add it to iPhone Home Screen
1. Open the published HTTPS address in Safari (not an in-app browser).
2. Tap the Share button (square with upward arrow).
3. Scroll and tap **Add to Home Screen**.
4. Edit the name to `AI Trader` if desired, then tap **Add**.
5. Launch it from the new Home Screen icon.

## Use
- Tap **Run one simulation cycle** to advance prices once.
- Tap **Start auto-simulation** to run a cycle every 15 seconds while the app remains open.
- Tap **Pause auto-simulation** to stop.
- **Reset paper account** clears local simulation history and resets the balance to $100.

## Future improvements
A true continuous system needs a server-side worker, persistent database, real market-data agreements/APIs, monitoring, and a separate broker paper-trading integration. A static PWA alone cannot keep executing JavaScript 24/7 when iOS suspends it.
